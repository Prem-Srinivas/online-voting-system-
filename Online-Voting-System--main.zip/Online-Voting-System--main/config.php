<?php 

    $db = mysqli_connect("localhost", "root", "", "onlinevotingsystem") or die("Connectivity Failed");

?>